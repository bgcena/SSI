import json
from urlparse import urljoin
import requests
import pymysql
import ssl, socket
import json
import hashlib

class GetCertDetails():
    def __init__(self,hostname):
        self.hostname = hostname
    
    def get_cert_details(self):
        hostname = self.hostname
        ctx = ssl.create_default_context()
        soc = ctx.wrap_socket(socket.socket(), server_hostname=hostname)
        soc.connect((hostname, 443))
        cert = soc.getpeercert()
        pemEncodedCert= ssl.DER_cert_to_PEM_cert(soc.getpeercert(True))
        fingerprint  = hashlib.sha1(pemEncodedCert).hexdigest()

        CN = ""
        notBefore = ""
        notAfter = ""
        subjectAlternativeNames = []

        for subject in cert['subject']:
            for i in subject:
                if str(i[0]) == "commonName":
                    CN = str(i[1])
        
        notBefore = cert['notBefore']
        notAfter = cert['notAfter']

        for subjectAltName in cert['subjectAltName']:
            if str(subjectAltName[0]) == "DNS":
                subjectAlternativeNames.append(str(subjectAltName[1]))

        tempjson = json.loads('{"subjectCN":"","subjectAlternativeNames":"","notBefore":"","notAfter":"","sha1Fingerprint":"","pemEncodedCert":""}')
        tempjson['pemEncodedCert'] = pemEncodedCert
        tempjson['subjectCN'] = CN
        tempjson['subjectAlternativeNames'] = subjectAlternativeNames
        tempjson['notBefore'] = notBefore
        tempjson['notAfter'] = notAfter
        tempjson['sha1Fingerprint'] = fingerprint

        return tempjson
