import json
from urlparse import urljoin
from akamai.edgegrid import EdgeGridAuth
from GetCertDetails import GetCertDetails
import List_Constants
import requests
import pymysql

class UpdateConfig():
    def __init__(self,configpropertyid,product, HostnameList, OriginHostName,CPCode, isSecureConfig,testid, contractid, groupid, accountid):
        self.configpropertyid = configpropertyid
        self.product = product
        self.isSecureConfig = isSecureConfig
        self.testid = testid
        self.contractid = contractid
        self.groupid = groupid
        self.accountid = accountid
        self.HostnameList = HostnameList
        self.OriginHostName = OriginHostName
        self.CpCode = CPCode
    
    def delete_keys_from_dict(self,dict_del, lst_keys):
        dict_foo = dict_del.copy()  
        for field in dict_foo.keys():
            if field in lst_keys:
                del dict_del[field]
            if type(dict_foo[field]) == dict:
                self.delete_keys_from_dict(dict_del[field], lst_keys)
            elif type(dict_foo[field]) == list:
                for item in dict_foo[field]:
                    if type(item) == dict:
                        self.delete_keys_from_dict(item,lst_keys)

        return dict_del

    def update_config(self):
        baseurl = 'https://akab-lisr7zghtr7gns32-n6n5udzpnsapkylo.luna.akamaiapis.net'
        s = requests.Session()
        s.auth = EdgeGridAuth(
        client_secret = 'BLFXKTyLp4Qj0AmV6Dmimif1b3cGN56nvnPkw9bmvHs=',
        access_token = 'akab-gzlgszkohztaxi3x-wcryzueehzdppzzs',
        client_token = 'akab-mn7r6jnqgfvbd45j-kki7iblhmqmfulfy',
        )

        db = pymysql.connect("localhost","root","password","FIVR" )
        cursor = db.cursor()
        sql = "SELECT A.ContentType, A.ExtensionType, A.SureRouteObject, A.CacheByPath FROM FIVR.Analysis A JOIN FIVR.Configuration B ON A.RequestId = B.RequestId WHERE A.RequestId = '%s'" %(self.testid)
        cursor.execute(sql)
        sql_results = cursor.fetchall()
        db.close()

        for a in sql_results:
            ContTypetmp = a[0]
            ExtnTypestmp = a[1]
            CacheByPathtmp = a[3]
            SRTOtmp = a[2]

        ContType = ContTypetmp.split(",")
        ExtnTypes = ExtnTypestmp.split(",")
        MandExtnTypes = List_Constants.MandExtnTypes
        for a in ExtnTypes:
            if a not in MandExtnTypes:
                MandExtnTypes.append(a)

        SRTO = SRTOtmp.split(",")
        CacheByPath = CacheByPathtmp.split(",")

        prule_path = "/papi/v1/properties/"+self.configpropertyid+"/versions/1/rules?contractId="+self.contractid+"&groupId="+self.groupid+"&accountSwitchKey="+self.accountid

        prule_res = s.get(urljoin(baseurl, prule_path))

        prule = json.loads(prule_res.text)


        # Update Origin in Origin Behavior

        # Update Default Origin Behavior
        for behavior in prule['rules']['behaviors']:
            if behavior['name'] == 'origin':
                behavior['options']['hostname'] = self.OriginHostName
        
        if self.isSecureConfig == "Yes":
            for behavior in prule['rules']['behaviors']:
                if behavior['name'] == 'origin':
                    behavior['options'] = {
                        "originType": "CUSTOMER",
                        "hostname": str(self.OriginHostName),
                        "forwardHostHeader": "REQUEST_HOST_HEADER",
                        "cacheKeyHostname": "REQUEST_HOST_HEADER",
                        "compress": True,
                        "enableTrueClientIp": False,
                        "httpPort": 80,
                        "originCertificate": "",
                        "verificationMode": "CUSTOM",
                        "ports": "",
                        "httpsPort": 443,
                        "originSni": True,
                        "customValidCnValues": [
                            "{{Origin Hostname}}",
                            "{{Forward Host Header}}"
                        ],
                        "originCertsToHonor": "CUSTOM_CERTIFICATES",
                        "customCertificates": [GetCertDetails(self.OriginHostName).get_cert_details()]
                        }
            
            prule['rules']['options']['is_secure'] = True
        
        for behavior in prule['rules']['behaviors']:
            if behavior['name'] == 'cpCode':
                behavior['options'] = {
                    "value": {
                        "id": int(self.CpCode)
                    }
                }
        

        # Update Extention Types for Static Content
        if self.product == "ION":
            for children in prule['rules']['children']:
                if children['name'] == "Offload":
                    for subchild in children['children']:
                        if subchild['name']=='Static Objects':
                            for criteria in subchild['criteria']:
                                if criteria['name']=="fileExtension":
                                    criteria["options"]["values"] = MandExtnTypes
            
            for children in prule['rules']['children']:
                if children['name'] == "Performance":
                    for behavior in children['behaviors']:
                        if behavior['name'] == 'sureRoute':
                            behavior['options']['testObjectUrl'] = SRTO[0]
            
            for children in prule['rules']['children']:
                if children['name'] == "Performance":
                    for subchild in children['children']:
                        if subchild['name']=='Compressible Objects':
                            for criteria in subchild['criteria']:
                                if criteria['name']=="contentType":
                                    criteria["options"]["values"] = ContType



        else:
            for behavior in prule['rules']['behaviors']:
                if behavior['name'] == 'sureRoute':
                    behavior['options']['testObjectUrl'] = SRTO[0]

            for children in prule['rules']['children']:
                if children['name'] == "Static Content":
                    for criteria in children['criteria']:
                            if criteria['name']=="fileExtension":
                                criteria["options"]["values"] = MandExtnTypes

            # Update Content Types for Compression
            for children in prule['rules']['children']:
                if children['name'] == "Content Compression":
                    for criteria in children['criteria']:
                            if criteria['name']=="contentType":
                                criteria["options"]["values"] = ContType

        # Update Path based caching
        if CacheByPath[0]!= "":
            PathBasedCacheRule = json.loads("""{"name": "Path Caching","children": [],"behaviors": [{"name": "caching","options": {"mustRevalidate": false,"behavior": "MAX_AGE","ttl": "7d"}},{"name": "downstreamCache","options": {"sendPrivate": false,"allowBehavior": "GREATER","behavior": "ALLOW","sendHeaders": "CACHE_CONTROL_AND_EXPIRES"}}],"criteria": [{"name": "path","options": {"values": [],"matchOperator": "MATCHES_ONE_OF","matchCaseSensitive": false}}],"criteriaMustSatisfy": "all"}""")
            for criteria in PathBasedCacheRule["criteria"]:
                if criteria["name"]=="path":
                    criteria["options"]["values"] = CacheByPath
            
            for index, children in enumerate(prule['rules']['children']):
                if children['name'] == "Static Content":
                    prule['rules']['children'].insert(index+1,PathBasedCacheRule)
        
        prule['rules']['comments'] = "Initial Version Pushed from SAINT"

        pupdate_header = {
            'Content-Type': 'application/json',
            'PAPI-Use-Prefixes': 'false'
        }

        lst = []
        lst.append('uuid')
        lst.append('templateUuid')
        prule2 = self.delete_keys_from_dict(prule,lst)

        pupdate_res = s.put(urljoin(baseurl, prule_path), headers=pupdate_header, data=json.dumps(prule2))
        
        # print json.dumps(prule2)
        print pupdate_res.text
        return (pupdate_res.status_code)

        

        
