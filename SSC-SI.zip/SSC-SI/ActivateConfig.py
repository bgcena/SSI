import json
from urlparse import urljoin
from akamai.edgegrid import EdgeGridAuth
from UpdateConfigComment import UpdateConfigComment
import requests
import pymysql

class ActivateConfig():
    def __init__(self,configpropertyid,Username):
        self.configpropertyid = configpropertyid
        self.Username = Username

    def activate_config(self):
        baseurl = 'https://akab-556acphexmckxdwf-mv55g3nihy2y3wf5.luna.akamaiapis.net'
        s = requests.Session()
        s.auth = EdgeGridAuth(
            client_secret='aGx4XJ3DRJIxscyGfB2RaLe2JqKX7M2Iv9xW3nA7Ajw=',
            access_token='akab-zddyiew5gspaq4db-xvquxuk3mzmcxrlz',
            client_token='akab-tbvnwv2y7fj5c5l5-ic3fw7zwd7ce7w4l',
        )
        notifyemail = str(self.Username)+'@akamai.com'

        pinfo_path = '/papi/v1/properties/'+self.configpropertyid+'/activations?contractId=ctr_C-20G24V&groupId=grp_28580'
        pinfo_headers = {'PAPI-Use-Prefixes': 'true','Content-Type': 'application/json'}
        pinfo_data = json.dumps(
                {
                    "propertyVersion": 1,
                    "network": "STAGING",
                    "note": "Initial Config Pushed from SAINT",
                    "notifyEmails": [
                        notifyemail
                    ],
                    "acknowledgeAllWarnings": True,
                    "useFastFallback": False
                }   
            )

        pinfo_res = s.post(urljoin(baseurl,pinfo_path),headers=pinfo_headers,data=pinfo_data)
        print pinfo_res
        
        # pinfo_res1 = json.loads(pinfo_res.text)
        # if int(pinfo_res1['status']) != 201:
        #     if 'title' in pinfo_res1:
        #         if str(pinfo_res1['title'] == "Activation Warnings"):
        #             ack = []
        #             for warning in pinfo_res1['warnings']:
        #                 ack.append(warning['messageId'])
        #             pinfo_data_temp = json.loads('''{"propertyVersion": "1","network": "STAGING","note": "Initial Config Pushed from SSC","notifyEmails": ["'''+notifyemail+'''"],"acknowledgeWarnings": [],"useFastFallback": "False"}''')
        #             pinfo_data_temp['acknowledgeWarnings'] = ack

        #             pinfo_res = s.post(urljoin(baseurl,pinfo_path),headers=pinfo_headers,data=json.dumps(pinfo_data_temp))
        #             print pinfo_res
        

        pinfo_path = '/papi/v1/properties/'+self.configpropertyid+'/activations?contractId=ctr_C-20G24V&groupId=grp_28580'
        pinfo_headers = {'PAPI-Use-Prefixes': 'true','Content-Type': 'application/json'}
        pinfo_data = json.dumps(
                {
                    "propertyVersion": 1,
                    "network": "PRODUCTION",
                    "note": "Initial Config Pushed from SAINT",
                    "notifyEmails": [
                        notifyemail
                    ],
                    "acknowledgeAllWarnings": True,
                    "complianceRecord": {"noncomplianceReason": "NO_PRODUCTION_TRAFFIC"},
                    "useFastFallback": False
                }   
            )

        pinfo_res = s.post(urljoin(baseurl,pinfo_path),headers=pinfo_headers,data=pinfo_data)
        print pinfo_res.content

        # UpdateCommentStatus=""
        # pinfo_res1 = json.loads(pinfo_res.text)
        # if int(pinfo_res1['status']) != 201:
        #     if 'title' in pinfo_res1:
        #         if str(pinfo_res1['title'] == "Activation Warnings"):
        #             ack = []
        #             for warning in pinfo_res1['warnings']:
        #                 ack.append(warning['messageId'])
        #             if "msg_d91039294be022c8fe3b7ec50a175acb6562b364" in ack:
        #                 UpdateCommentStatustmp = UpdateConfigComment(self.configpropertyid)
        #                 UpdateCommentStatus = UpdateCommentStatustmp.update_config_comment()
        #                 if int (UpdateCommentStatus) == 200:
        #                     pinfo_res = s.post(urljoin(baseurl,pinfo_path),headers=pinfo_headers,data=pinfo_data)
        #                     pinfo_res1 = json.loads(pinfo_res.text)
        # if int(pinfo_res1['status']) != 201:
        #     if 'title' in pinfo_res1:
        #         if str(pinfo_res1['title'] == "Activation Warnings"):
        #             ack = []
        #             for warning in pinfo_res1['warnings']:
        #                 if str(warning['messageId']) not in ack:
        #                     ack.append(warning['messageId'])
        #             pinfo_data_temp = json.loads('''{"propertyVersion": "1","network": "PRODUCTION","note": "Initial Config Pushed from SSC","notifyEmails": ["'''+notifyemail+'''"],"acknowledgeWarnings": [],"useFastFallback": "False","complianceRecord": {"noncomplianceReason": "NO_PRODUCTION_TRAFFIC"}}''')
        #             pinfo_data_temp['acknowledgeWarnings'] = ack
        #             print ack
        #             pinfo_res = s.post(urljoin(baseurl,pinfo_path),headers=pinfo_headers,data=json.dumps(pinfo_data_temp))
        #             print pinfo_res.content

        return pinfo_res.status_code


			
        
        