import json
from urlparse import urljoin
from akamai.edgegrid import EdgeGridAuth
import requests
import pymysql

class AddEhnToConfig():
    def __init__(self,configpropertyid,product,HostnameList, Edgehostname, isSecureConfig, contractid, groupid, accountid):
        self.configpropertyid = configpropertyid
        self.product = product
        self.HostnameList = HostnameList
        self.isSecureConfig = isSecureConfig
        self.contractid = contractid
        self.groupid = groupid
        self.accountid = accountid
        self.Edgehostname = Edgehostname
    
    def addEHN_config(self):
        baseurl = 'https://akab-lisr7zghtr7gns32-n6n5udzpnsapkylo.luna.akamaiapis.net'
        s = requests.Session()
        s.auth = EdgeGridAuth(
        client_secret = 'BLFXKTyLp4Qj0AmV6Dmimif1b3cGN56nvnPkw9bmvHs=',
        access_token = 'akab-gzlgszkohztaxi3x-wcryzueehzdppzzs',
        client_token = 'akab-mn7r6jnqgfvbd45j-kki7iblhmqmfulfy',
        )

        #Update Edge Hostname
        pinfo_path = '/papi/v1/properties/'+self.configpropertyid+'/versions/1/hostnames?contractId='+self.contractid+'&groupId='+self.groupid+'&accountSwitchKey='+self.accountid+'&validateHostnames=false'
        pinfo_headers = {'PAPI-Use-Prefixes': 'true','Content-Type': 'application/json'}
        pinfo_data = json.dumps([{ "cnameType": "EDGE_HOSTNAME",
            "cnameFrom": Hostnames,
            "cnameTo": self.Edgehostname } for Hostnames in self.HostnameList])


        pinfo_res = s.put(urljoin(baseurl,pinfo_path),headers=pinfo_headers,data=pinfo_data)
        # print pinfo_res.content
        return (pinfo_res.status_code)