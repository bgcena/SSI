import os
import sys
import json
import time
import List_Constants
from urlparse import urlparse
from os.path import splitext
import pdb

class analysis():
    def __init__(self,harData,inputHostName,inputSubHostNames):
        self.harData = harData
        self.inputHostName = inputHostName
        self.inputSubHostNames = inputSubHostNames
        
    def logerror(self,e):
        dir = "Analysis Log Files"
        if not os.path.exists(dir):
            os.makedirs(dir)
        logerrfile = dir+"/"+self.inputHostName+str(time.strftime("%d%m%Y-%H%M"))
        logerr = open(logerrfile, "w")
        logerr.write("An error occurred.\nError Details: %s" % e)
        logerr.close
        raise Exception("Error occurred or invalid HAR File.\nPlease refer log file for more detail: "+logerrfile)
            
    def get_Status(self):
        allHosts = self.get_AllHosts()
        is_Status = False
        is_Hosts_Match = True
        try:
            objects=self.harData['log']
            for i in objects['entries']:
                if (str(i['_host']).lower()) == self.inputHostName.lower() and (str(i['_responseCode']) == "200"):
                    is_Status = True
                    break
            if len(self.inputSubHostNames)>0:
                for i in self.inputSubHostNames:
                    if i not in allHosts:
                        is_Hosts_Match = False
                        break
            if (is_Status and is_Hosts_Match):
                return True
            else:
                return False
            
        except Exception as e:
            self.logerror(str(e))
                        
            
        
    #Function to get Base Page URL
    def get_BasePageURL(self):
        varBPURL = ""
        try:
            objects = self.harData['log']
            for i in objects['entries']:
                if str(i['response']['status']) == "200":
                    for j in i['request']['headers']:
                        if str(j['name']) == 'Host' and (str(j['value']) == self.inputHostName or str(j['value']) in self.inputSubHostNames):
                            varBPURL = str(i['request']['url'])
                if varBPURL != "":
                    break

            if varBPURL != "":
                # varBPURL = urlparse(varBPURL).path
                return varBPURL
            else:
                return "/"
        except Exception as e:
            self.logerror(str(e))

    
    #Function to get All Hosts present in the URL except primary hostname
    def get_AllHosts(self):
        varHosts = []
        varCompHosts = []
        try:
            objects = self.harData['log']
            for i in objects['entries']:
                for j in i['request']['headers']:
                    if j['name'] == 'Host':
                        tmpHosts = str(j['value'])
                        varCompHosts.append(tmpHosts)
                        if not tmpHosts in varHosts:
                            varHosts.append(tmpHosts)
            if self.inputHostName in varHosts:
                varHosts.remove(self.inputHostName)
            return varHosts, varCompHosts
        
        except Exception as e:
            self.logerror(str(e))
            
    #Function to get All Hosts present in the URL including primary hostname
    def get_AllHosts_includingPrimary(self):
        varHosts = []
        varCompHosts = []
        try:
            objects = self.harData['log']
            for i in objects['entries']:
                for j in i['request']['headers']:
                    if j['name'] == 'Host':
                        tmpHosts = str(j['value'])
                        varCompHosts.append(tmpHosts)
                        if not tmpHosts in varHosts:
                            varHosts.append(tmpHosts)
            return varHosts, varCompHosts
        
        except Exception as e:
            self.logerror(str(e))
    
    #Function to get Content Types that can be COMPRESSED
    def get_ContentType(self):
        ConTypes = List_Constants.ConTypes
        varTypeValue = ""
        tmpType = []
        varContentTypes = [] 
        varContentTypes.append('text/html')
        varContentTypes.append('text/css')
        varContentTypes.append('application/x-javascript')
        varObjectURLs = []
        try:
            objects = self.harData['log']
            for i in objects['entries']:
                if str(i['response']['status']) == "200":
                    for j in i['request']['headers']:
                        if str(j['name']) == 'Host' and (str(j['value']) == self.inputHostName or str(j['value']) in self.inputSubHostNames):
                            varTypeValue = str(i['response']['content']['mimeType'])
                            varTypeValue = varTypeValue.replace('; charset=utf-8','')
                            varTypeValue = varTypeValue.replace(';charset=utf-8','')
                            if varTypeValue in ConTypes:
                                varObjectURLs.append(str(i['request']['url'])) 
                                if varTypeValue not in varContentTypes:
                                    varContentTypes.append(varTypeValue)
            varContentTypes = [a + '*' for a in varContentTypes]
            return varContentTypes,varObjectURLs
        
        except Exception as e:
            self.logerror(str(e))

    
    #Function to get Sure Route Test Object
    def get_SureRouteObject(self):
        SureRouteURL = ""
        conLen = 0
        conType = None
        SRContType = List_Constants.SRContType
        NonSRExtn = List_Constants.NonSRExtn
        try:
            objects = self.harData['log']
            for i in objects['entries']:
                if str(i['response']['status']) == "200":
                    for j in i['request']['headers']:
                        if str(j['name']) == 'Host' and str(j['value']) == self.inputHostName:
                            tmpURL =  str(i['request']['url'])
                            parsedURL = urlparse(tmpURL)
                            tmphost,tmpExt = splitext(parsedURL.path)
                            tmpExt = tmpExt.replace('.','')
                            for k in i['response']['headers']:
                                if (str(k['name']).lower() == "content-length"):
                                    conLen = str(k['value'])
                                if (str(k['name']).lower() == "content-type"):
                                    conType = str(k['value'])

                if conType is not None:
                    conType = conType.replace(';charset=utf-8', '')
                    conType = conType.replace('; charset=utf-8', '')
        
                if (int(conLen) > 4000 and int(conLen) < 56000 and conType in SRContType and tmpExt not in NonSRExtn):
                    SureRouteURL = str(i['request']['url'])
                    break
            if SureRouteURL != "":
                return SureRouteURL
            else:
                return self.get_BasePageURL()
        
        except Exception as e:
            self.logerror(str(e))
    #Function to check presence of Vary header
    def get_is_Vary(self):
        is_Vary = False
        VaryURLList =[]
        check_is_gzip = False
        ContNotGzip = []
        try:
            objects = self.harData['log']
            for i in objects['entries']:
                if str(i['response']['status']) == "200":
                    for j in i['request']['headers']:
                        if str(j['name']) == 'Host' and (str(j['value']) == self.inputHostName or str(j['value']) in self.inputSubHostNames):
                            for k in i['response']['headers']:
                                if str(k['name']) == 'Vary':
                                    if str(k['value']) != "Accept-Encoding":
                                        is_Vary = True
                                        VaryURLList.append(str(i['request']['url']))
                                    else:
                                        check_is_gzip = True
                            if (check_is_gzip):
                                for k in i['response']['headers']:
                                    if str(k['name']).lower() == 'content-encoding' and str(k['value']).lower() != "gzip":
                                        ContNotGzip.append(str(i['request']['url']))
                            check_is_gzip = False
            return is_Vary,VaryURLList,ContNotGzip           
        
        except Exception as e:
            self.logerror(str(e))                       


       
    #Function to check presence of Age header
    def get_is_Age(self):
        is_Age = False
        AgeURLList = []
        try:
            objects = self.harData['log']
            for i in objects['entries']:
                if str(i['response']['status']) == "200":
                    for j in i['request']['headers']:
                        if str(j['name']) == 'Host' and (str(j['value']) == self.inputHostName or str(j['value']) in self.inputSubHostNames):
                            for k in i['response']['headers']:
                                if str(k['name']) == 'Age':
                                    is_Age = True
                                    AgeURLList.append(str(i['request']['url']))
            return is_Age,AgeURLList           
        
        except Exception as e:
            self.logerror(str(e))    
    
    #Function to check presence of LastModified header
    def get_is_not_LM(self):
        LmURLList = []
        try:
            objects = self.harData['log']
            for i in objects['entries']:
                is_notLM = True
                if str(i['response']['status']) == "200":
                    for j in i['request']['headers']:
                        if str(j['name']) == 'Host' and (str(j['value']) == self.inputHostName or str(j['value']) in self.inputSubHostNames):
                            for k in i['response']['headers']:
                                if str(k['name']).lower() == 'last-modified':
                                    is_notLM = False
                            if (is_notLM):
                                LmURLList.append(str(i['request']['url']))
                                    
            return LmURLList           
        
        except Exception as e:
            self.logerror(str(e)) 

    def get_Cacheable_Objects(self):
        ExtnTypes = List_Constants.ExtnTypes
        cacheContTypes = List_Constants.cacheContTypes
        varExtTypes = []
        var_Cacheable_URLs = []
        var_TParam_URLs = []
        var_CacheByPath = []
        var_CacheByPath_URLs = []
        var_allObjects = []
        var_dynamic = []
        tmpURL = ""
        parsedURL = ""
        tmphost = ""
        tmpExt = ""
        is_Tparam = False
        
        #Fetching the extensions in URL that match with pre-defined extensions
        try:
            objects = self.harData['log']
            for i in objects['entries']:
                if str(i['response']['status']) == "200":
                    for j in i['request']['headers']:
                        if str(j['name']) == 'Host' and (str(j['value']) == self.inputHostName or str(j['value']) in self.inputSubHostNames):
                            tmpURL =  str(i['request']['url'])
                            var_allObjects.append(tmpURL)
                            parsedURL = urlparse(tmpURL)
                            tmphost,tmpExt = splitext(parsedURL.path)
                            tmpExt = tmpExt.replace('.','')
                    
                            if tmpExt in ExtnTypes:
                                var_Cacheable_URLs.append(tmpURL)
                                if not tmpExt in varExtTypes:
                                    varExtTypes.append(tmpExt)
                    
                    #To check if it is .axd file and ignore T parameter if it is present
                            if tmpExt == "axd":
                                strT = "T="
                                strD = "D="
                                if strT in tmpURL or strT.lower() in tmpURL or strD in tmpURL or strD.lower() in tmpURL:
                                    is_Tparam = True
                                    var_TParam_URLs.append(tmpURL)
    
                    #Caching based on path - through content-type and having different extensions or no extensions.
                            for k in i['response']['headers']:
                                if str(k['name']).lower() == 'content-type' and not tmpExt:
                                    if ((str(k['value']).lower().replace('; charset=utf-8','') in cacheContTypes) or (str(k['value']).lower().replace(';charset=utf-8','') in cacheContTypes)):
                                        if tmpURL not in var_Cacheable_URLs:
                                            var_Cacheable_URLs.append(tmpURL)
                                        var_CacheByPath_URLs.append(tmpURL)
                                        tmpURL = tmpURL.rpartition("/")[0].replace('http://','').replace('https://','').replace(str(self.inputHostName),'')
                                        for a in self.inputSubHostNames:
                                            tmpURL = tmpURL.replace(str(a),'')
                                        if not tmpURL in var_CacheByPath:
                                            var_CacheByPath.append(tmpURL)
                            
            for item in var_allObjects:
                if not item in var_Cacheable_URLs and not item in var_CacheByPath_URLs:
                    var_dynamic.append(item)
            
            return varExtTypes,var_Cacheable_URLs,is_Tparam,var_TParam_URLs,var_CacheByPath,var_CacheByPath_URLs,var_dynamic

        except Exception as e:
            self.logerror(str(e))
    #Objects that do not return 200 response
    
    def get_Error_Objects(self):
        ErrorStatus = {}
        ErrorStatus['Status']={}
        tmpstatus=""
        try:
            objects = self.harData['log']
            for i in objects['entries']:
                if str(i['response']['status']) != "200":
                    for j in i['request']['headers']:
                        if str(j['name']) == 'Host' and (str(j['value']) == self.inputHostName or str(j['value']) in self.inputSubHostNames):
                            tmpstatus = str(i['response']['status'])
                            ErrorStatus["Status"].setdefault(tmpstatus,[]).append(str(i['request']['url']))
            return ErrorStatus
        
        except Exception as e:
            self.logerror(str(e))