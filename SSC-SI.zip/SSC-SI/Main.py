from flask import Flask, render_template, request, session, send_file
from flask_celery import make_celery
from ssttest import getHar
from urlparse import urlparse
from HarAnalysis import analysis
from CloneConfig import CloneConfig
from AddEHNtoConfig import AddEhnToConfig
from UpdateConfig import UpdateConfig
from ActivateConfig import ActivateConfig
from CreateCPCode import CreateCPCode
from datetime import datetime
from selenium import webdriver
import requests
import string
import random
import pymysql
import time
import json
import re
import hashlib

app = Flask(__name__)
app.secret_key = 'You will never guess'
app.config['CELERY_BROKER_URL'] = 'pyamqp://localhost//'
app.config['MAIL_SERVER'] = 'email.msg.corp.akamai.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'akamai\ksuresh'
app.config['MAIL_PASSWORD'] = 'Ksreddy#8910'

celery = make_celery(app)


@celery.task(name='Main.runtask')
def runtask(Req_id, URLCount):
    task_status = False
    db = pymysql.connect("localhost", "root", "password", "FIVR")
    cursor = db.cursor()
    while(task_status == False):
        
        sql = "SELECT Status,AnalysisId FROM FIVR.Analysis WHERE AnalysisId = (SELECT MAX(AnalysisId)-%s FROM FIVR.Analysis WHERE RequestId = '%s')" % (
            URLCount, Req_id)
        cursor.execute(sql)
        previous_task_status = cursor.fetchone()
        print previous_task_status
        if (str(previous_task_status[0]) == "Completed" or str(previous_task_status[0]) == "Failed"):
            sql = "SELECT AnalysisId, Url, Mobile FROM FIVR.Analysis WHERE RequestId = '%s' AND Status = '%s'" % (
                Req_id, 'Pending')
            cursor.execute(sql)
            tasklist = cursor.fetchall()
            for task in tasklist:
                har = getHar(task[1], task[2], task[0])
                harpathtemp = har.getHarFile()
                harpath = harpathtemp[0]
                if (harpathtemp[1] == 'yes'):
                    sql = "UPDATE FIVR.Analysis SET HarPath = '%s' , Status = '%s' WHERE AnalysisId = '%s'" % (
                        harpath, 'Completed', task[0])
                    try:
                        cursor.execute(sql)
                        db.commit()
                    except:
                        db.rollback()
                    task_status = True
                else:
                    sql = "UPDATE FIVR.Analysis SET HarPath = '%s' , Status = '%s' WHERE AnalysisId = '%s'" % (
                        harpath, 'Failed', task[0])
                    try:
                        cursor.execute(sql)
                        db.commit()
                    except:
                        db.rollback()
                    task_status = True
        time.sleep(5)
        
    
    sql = "SELECT Status, Functionalityid from FIVR.Analysis WHERE RequestId = '%s'" %(Req_id)
    cursor.execute(sql)
    sql_results = cursor.fetchall()
    result_status = True
    is_functionality = False
    for status in sql_results:
        if str(status[0]) != "Completed":
            result_status = False
        if status[1] is not None:
            is_functionality = True
    
    if result_status:
        if is_functionality:
            sql = "UPDATE FIVR.Requests SET Status = 'Review Functionality' WHERE RequestId = '%s'" % (Req_id)
        else:
            sql = "UPDATE FIVR.Requests SET Status = 'Review' WHERE RequestId = '%s'" % (Req_id)
        try:
            cursor.execute(sql)
            db.commit()
        except:
            db.rollback()
    
    db.close()


@app.route('/', methods=['GET', 'POST'])
def login():
	is_valid = "Yes"
	return render_template('login.html', is_valid=is_valid)

@app.route('/RegisterUser', methods=['GET', 'POST'])
def registerUser():
    is_valid = "Yes"
    is_register = "No"
    if request.method == "POST":
        FirstName = request.form.get('firstname')
        LastName = request.form.get('lastname')
        EmailId = request.form.get('email')
        Password = request.form.get('passwd')
        md5Pwd = hashlib.md5(Password.encode())
        Passwordtemp = str(md5Pwd.hexdigest())

        #validate User
        db = pymysql.connect("localhost", "root", "password", "FIVR")
        cursor = db.cursor()
        sql = "SELECT COUNT(UserId) FROM FIVR.Users WHERE EmailId = '%s'" % (
            EmailId)
        cursor.execute(sql)
        sql_results = cursor.fetchone()
        if int(sql_results[0] > 0):
            is_register = "No"
            return render_template('login.html', isvalid=is_valid, is_register=is_register)

        #Create User
        else:
            sql = "INSERT INTO FIVR.Users (FirstName, LastName, EMailId, Password) VALUES ('%s','%s','%s','%s')" % (
                FirstName, LastName, EmailId, Passwordtemp)
            cursor.execute(sql)
            db.commit()
            is_register = "Registered"
            return render_template('login.html', isvalid=is_valid, is_register=is_register)
    else:
		is_valid = "Yes"
		return render_template('login.html', is_valid=is_valid)

@app.route('/home', methods=['GET', 'POST'])
def home():
    is_valid = "Yes"
    is_register = "NA"
    if request.method == "POST":
        if session.get('emailid') is not None and session.get('firstname') is not None and session.get('userid') is not None:
            EmailId = session.get('emailid')
            firstname = session.get('firstname')
            userid = session.get('userid')
            db = pymysql.connect("localhost", "root", "password", "FIVR")
            cursor = db.cursor()
            sql = "SELECT RequestName, RequestId, Status from FIVR.Requests WHERE UserId = '%s' order by timestamp desc" % (userid)
            cursor.execute(sql)
            sql_results = cursor.fetchall()
            jsonresults = {}
            jsonresults['data']=[]
            analysing=""
            disabled=""
            for a in sql_results:
                if str(a[2]) == "Review":
                    path = "/ShowHosts"
                    disabled = ""
                elif str(a[2]) == "Check Functionality":
                    path = "/CheckFunctionality"
                    disabled = ""
                elif str(a[2]) == "Review Functionality":
                    path = "/ReviewFunctionality"
                    disabled = ""
                elif str(a[2]) == "View Report":
                    path = "/ViewReport"
                    disabled = ""
                elif str(a[2]) == "Analyzing":
                    path = ""
                    disabled = "disabled"
                    analysing = "analysing"
                else:
                    path = ""
                    disabled = "disabled"
                    analysing = ""
                jsonresults['data'].append(
                    {
                        "ReqName": a[0],
                        "ReqId": a[1],
                        "Status": a[2],
                        "Path": path,
                        "Disabled": disabled,
                        "Analysing": analysing
                    }
                )
            return render_template('home.html', firstname=firstname, EmailId=EmailId, requests=jsonresults['data'])

        else:
            EmailId = request.form.get('username')
            Password = request.form.get('password')
            md5Pwd = hashlib.md5(Password.encode())
            Passwordtemp = str(md5Pwd.hexdigest())

            #validate User
            db = pymysql.connect("localhost", "root", "password", "FIVR")
            cursor = db.cursor()
            sql = "SELECT COUNT(UserId),FirstName,LastName,UserId FROM FIVR.Users WHERE EmailId = '%s' and Password = '%s' group by UserId" % (
                EmailId, Passwordtemp)
            cursor.execute(sql)
            sql_results = cursor.fetchone()
            if str(sql_results[0]) == "1":
                firstname = str(sql_results[1])
                userid = str(sql_results[3])
                session['emailid'] = EmailId
                session['firstname'] = firstname
                session['userid'] = userid
                sql = "SELECT RequestName, RequestId, Status from FIVR.Requests WHERE UserId = '%s' order by timestamp desc" % (userid)
                cursor.execute(sql)
                sql_results = cursor.fetchall()
                jsonresults = {}
                jsonresults['data']=[]
                analysing=""
                disabled=""
                for a in sql_results:
                    if str(a[2]) == "Review":
                        path = "/ShowHosts"
                        disabled = ""
                    elif str(a[2]) == "Check Functionality":
                        path = "/CheckFunctionality"
                        disabled = ""
                    elif str(a[2]) == "Review Functionality":
                        path = "/ReviewFunctionality"
                        disabled = ""
                    elif str(a[2]) == "View Report":
                        path = "/ViewReport"
                        disabled = ""
                    elif str(a[2]) == "Analyzing":
                        path = ""
                        disabled = "disabled"
                        analysing = "analysing"
                    else:
                        path = ""
                        disabled = "disabled"
                        analysing = ""
                    jsonresults['data'].append(
                            {
                                "ReqName": a[0],
                                "ReqId": a[1],
                                "Status": a[2],
                                "Path": path,
                                "Disabled": disabled,
                                "Analysing": analysing
                            }
                        )
                return render_template('home.html', firstname=firstname, EmailId=EmailId, requests=jsonresults['data'])
            else:
                is_valid = "No"
                return render_template('login.html', is_valid=is_valid, is_register=is_register)

    else:
		is_valid = "Yes"
		return render_template('login.html', is_valid=is_valid)

@app.route('/NewRequest', methods=['GET', 'POST'])
def NewRequest():
    if request.method == 'POST':
        if session.get('emailid') is not None and session.get('firstname') is not None and session.get('userid') is not None:
            EmailId = session.get('emailid')
            firstname = session.get('firstname')
            userid = session.get('userid')

        # Assigning inputs from Form
        url = []
        if request.form.get('ReqName') != '':
            ReqName = request.form.get('ReqName')
        if request.form.get('txtUrl1') != '':
            url.append(request.form.get('txtUrl1'))
        if request.form.get('txtUrl2') != '':
            url.append(request.form.get('txtUrl2'))
        if request.form.get('txtUrl3') != '':
            url.append(request.form.get('txtUrl3'))
        # mobile = request.form.get('DeviceType')
        mobile = "No"
        chars = string.letters.upper() + string.digits
        Reqid_size = 10
        Req_id = ''.join((random.choice(chars)) for x in range(Reqid_size))
        if len(url) == 1:
            sql = "INSERT INTO FIVR.Requests(RequestName,RequestId,UserId,DeviceType,Url1,status,timestamp) VALUES ('%s','%s','%s','%s','%s','Analyzing',UTC_TIMESTAMP())" % (
                ReqName, Req_id, userid, mobile, url[0])
        elif len(url) == 2:
            sql = "INSERT INTO FIVR.Requests(RequestName,RequestId,UserId,DeviceType,Url1,Url2,status,timestamp) VALUES ('%s','%s','%s','%s','%s','%s','Analyzing',UTC_TIMESTAMP())" % (
                ReqName, Req_id, userid, mobile, url[0], url[1])
        else:
            sql = "INSERT INTO FIVR.Requests(RequestName,RequestId,UserId,DeviceType,Url1,Url2,Url3,status,timestamp) VALUES ('%s','%s','%s','%s','%s','%s','%s','Analyzing',UTC_TIMESTAMP())" % (
                ReqName, Req_id, userid, mobile, url[0], url[1], url[2])

        db = pymysql.connect("localhost", "root", "password", "FIVR")
        cursor = db.cursor()
        try:
            cursor.execute(sql)
            db.commit()
        except:
            db.rollback()

        for a in url:
            parsed = urlparse(a)
            HostName = parsed.netloc
            sql2 = "INSERT INTO FIVR.Analysis(RequestId,Url,Mobile,HostName,Status) VALUES ('%s','%s','%s','%s','%s')" % (Req_id, a, mobile, HostName, 'Pending')
            try:
                cursor.execute(sql2)
                db.commit()
            except:
                db.rollback()
        
        runtask.delay(Req_id, len(url))

        
        sql = "SELECT RequestName, RequestId, Status from FIVR.Requests WHERE UserId = '%s' order by timestamp desc" % (userid)
        cursor.execute(sql)
        sql_results = cursor.fetchall()
        jsonresults = {}
        jsonresults['data']=[]
        analysing=""
        disabled=""
        for a in sql_results:
            if str(a[2]) == "Review":
                path = "/ShowHosts"
                disabled = ""
            elif str(a[2]) == "Check Functionality":
                path = "/CheckFunctionality"
                disabled = ""
            elif str(a[2]) == "Review Functionality":
                path = "/ReviewFunctionality"
                disabled = ""
            elif str(a[2]) == "View Report":
                path = "/ViewReport"
                disabled = ""
            elif str(a[2]) == "Analyzing":
                path = ""
                disabled = "disabled"
                analysing = "analysing"
            else:
                path = ""
                disabled = "disabled"
                analysing = ""
            jsonresults['data'].append(
                    {
                        "ReqName": a[0],
                        "ReqId": a[1],
                        "Status": a[2],
                        "Path": path,
                        "Disabled": disabled,
                        "Analysing": analysing
                    }
                )
        return render_template('home.html', firstname=firstname, EmailId=EmailId, requests=jsonresults['data'])
    
    else:
		is_valid = "Yes"
		return render_template('login.html',is_valid=is_valid)

@app.route('/ShowHosts', methods=['GET', 'POST'])
def showHosts():
    if request.method == 'POST':
        if session.get('emailid') is not None and session.get('firstname') is not None and session.get('userid') is not None:
            EmailId = session.get('emailid')
            firstname = session.get('firstname')
            userid = session.get('userid')
        Req_id = request.form.get('Req_id')
        db = pymysql.connect("localhost", "root", "password", "FIVR")
        cursor = db.cursor()
        sql = "SELECT HarPath, HostName, SubHostName, URL FROM FIVR.Analysis WHERE RequestId = '%s' AND FunctionalityId IS NULL" % (
		    Req_id)
        cursor.execute(sql)
        sql_results = cursor.fetchall()
        db.close()
        hosts = []
        HostCnt = []
        for task in sql_results:
            harpath = task[0]
            with open(harpath) as json_data:
                harData = json.load(json_data)
            inputHostname = task[1]
            inputSubHostname = task[2]
            # url = task[3]
            data = analysis(harData, inputHostname, inputSubHostname)
            tmphosts, tmpHostCnt = data.get_AllHosts()
            for a in tmphosts:
                if not a in hosts:
                    hosts.append(a)
            HostCnt.extend(tmpHostCnt)
        HostCntList = []
        # print hosts
        for item in hosts:
            HostCntList.append(item+'('+str(HostCnt.count(item))+')')
        HostCntList.sort(key=lambda x: int(
            x[x.index('(')+1:x.index(')')]), reverse=True)
        return render_template('ShowHosts.html', host=HostCntList, Req_id=Req_id, firstname = firstname)
    else:
		is_valid = "Yes"
		return render_template('login.html',is_valid=is_valid)

@app.route('/analysis', methods=['GET', 'POST'])
def analysis1():
    if request.method == 'POST':
        if session.get('emailid') is not None and session.get('firstname') is not None and session.get('userid') is not None:
            EmailId = session.get('emailid')
            firstname = session.get('firstname')
            userid = session.get('userid')
        Req_id = request.form.get('Req_id')
        tmpinputSubHostname = request.form.getlist('hostnames')
        inputSubHostname = []
        for item in tmpinputSubHostname:
            inputSubHostname.append(re.sub(r'\(\d+\)', '', item))

        strinputSubHostname = ', '.join(inputSubHostname)
        db = pymysql.connect("localhost", "root", "password", "FIVR")
        cursor = db.cursor()
        sql = "UPDATE FIVR.Analysis SET SubHostName = '%s' WHERE RequestId = '%s' AND FunctionalityId IS NULL" % (
            strinputSubHostname, Req_id)
        try:
            cursor.execute(sql)
            db.commit()
        except:
            db.rollback()

        sql = "SELECT HarPath,HostName,URL FROM FIVR.Analysis WHERE RequestId = '%s' AND FunctionalityId IS NULL" % (
            Req_id)
        cursor.execute(sql)
        sql_results = cursor.fetchall()
        db.close()
        tmpbasepage = []
        basepage = []
        varconttype = []
        varcontypeurl = []
        varyurl = []
        contnotgzip = []
        ageurl = []
        varExtTypes = []
        var_Cacheable_URLs = []
        var_TParam_URLs = []
        var_CacheByPath = []
        var_CacheByPath_URLs = []
        var_dynamic = []
        tmpSureRouteURL = []
        SureRouteURL = []
        LmURL = []
        is_Tparam = "yes"
        Tparam = "Yes"
        ErrorStatus = {}
        ErrorStatus['Status'] = {}
        for task in sql_results:
            harpath = task[0]
            with open(harpath) as json_data:
                harData = json.load(json_data)
            inputHostname = task[1]
            url = task[2]

            data1 = analysis(harData, inputHostname, inputSubHostname)
            tmpbasepage.append(data1.get_BasePageURL())
            for a in range(len(tmpbasepage)):
                if tmpbasepage[a] == "/":
                    tmpbasepage[a] = url
            for a in tmpbasepage:
                if not urlparse(a).path in basepage:
                    basepage.append(urlparse(a).path)

            tmpvarconttype, tmpvarcontypeurl = data1.get_ContentType()
            for a in tmpvarconttype:
                if not a in varconttype:
                    varconttype.append(a)
            for a in tmpvarcontypeurl:
                if not a in varcontypeurl:
                    varcontypeurl.append(a)

            is_vary, tmpvaryurl, tmpcontnotgzip = data1.get_is_Vary()
            if is_vary:
                vary = "Yes"
            else:
                vary = "No"
            for a in tmpvaryurl:
                if not a in varyurl:
                    varyurl.append(a)
            for a in tmpcontnotgzip:
                if not a in contnotgzip:
                    contnotgzip.append(a)

            is_age, tmpageurl = data1.get_is_Age()
            if is_age:
                age = "Yes"
            else:
                age = "No"
            for a in tmpageurl:
                if not a in ageurl:
                    ageurl.append(a)

            tmpvarExtTypes, tmpvar_Cacheable_URLs, is_Tparam, tmpvar_TParam_URLs, tmpvar_CacheByPath, tmpvar_CacheByPath_URLs, tmpvar_dynamic = data1.get_Cacheable_Objects()
            if is_Tparam:
                Tparam = "Yes"
            else:
                Tparam = "No"
            for a in tmpvarExtTypes:
                if not a in varExtTypes:
                    varExtTypes.append(a)
            for a in tmpvar_Cacheable_URLs:
                if not a in var_Cacheable_URLs:
                    var_Cacheable_URLs.append(a)
            for a in tmpvar_TParam_URLs:
                if not a in var_TParam_URLs:
                    var_TParam_URLs.append(a)
            for a in tmpvar_CacheByPath:
                if not a in var_CacheByPath:
                    var_CacheByPath.append(a)
            for a in tmpvar_CacheByPath_URLs:
                if not a in var_CacheByPath_URLs:
                    var_CacheByPath_URLs.append(a)
            for a in tmpvar_dynamic:
                if not a in var_dynamic:
                    var_dynamic.append(a)

            tmpSureRouteURL.append(data1.get_SureRouteObject())
            for a in tmpSureRouteURL:
                if not urlparse(a).path in SureRouteURL:
                    SureRouteURL.append(urlparse(a).path)

            # ErrorStatus = data1.get_Error_Objects()

            tmpLmURL = data1.get_is_not_LM()
            if len(tmpLmURL) > 0:
                isnot_LM = "Yes"
                for a in tmpLmURL:
                    if not a in LmURL:
                        LmURL.append(a)
            else:
                isnot_LM = "No"

        db = pymysql.connect("localhost", "root", "password", "FIVR")
        cursor = db.cursor()
        sql = "UPDATE FIVR.Analysis SET BasePage = '%s',ContentType ='%s', VaryHeader = '%s', AgeHeader = '%s', ExtensionType = '%s', TParameter = '%s', CacheByPath = '%s', SureRouteObject = '%s' WHERE RequestId = '%s'" % (
            ",".join(basepage), ",".join(varconttype), vary, age, ",".join(varExtTypes), Tparam, ",".join(var_CacheByPath), ",".join(SureRouteURL), Req_id)
        try:
            cursor.execute(sql)
            db.commit()
        except:
            db.rollback()
        db.close()
        return render_template('analysis.html', basepage=tmpbasepage, varconttype=varconttype, varExtTypes=varExtTypes, Tparam=Tparam, var_CacheByPath=var_CacheByPath, var_Cacheable_URLs=var_Cacheable_URLs, var_TParam_URLs=var_TParam_URLs, vary=vary, varyurl=varyurl, contnotgzip=contnotgzip, age=age, ageurl=ageurl, var_CacheByPath_URLs=var_CacheByPath_URLs, SureRouteURL=tmpSureRouteURL[0], var_dynamic=var_dynamic, isnot_LM=isnot_LM, LmURL=LmURL, Req_id=Req_id, firstname=firstname )
    
    else:
		is_valid = "Yes"
		return render_template('login.html',is_valid=is_valid)

@app.route('/Review', methods=['GET', 'POST'])
def ReviewFeatures():
    if request.method == 'POST':
        if session.get('emailid') is not None and session.get('firstname') is not None and session.get('userid') is not None:
            EmailId = session.get('emailid')
            firstname = session.get('firstname')
            userid = session.get('userid')
        Req_id = request.form.get('Req_id')
        db = pymysql.connect("localhost", "root", "password", "FIVR")
        cursor = db.cursor()
        sql = "SELECT HostName, SubHostName FROM FIVR.Analysis WHERE RequestId = '%s'" % (Req_id)
        cursor.execute(sql)
        sql_results = cursor.fetchall()
        db.close()
        HostnameList = ""
        HostnameListtmp = []
        SubHostNameList = ""
        for task in sql_results:
            if task[0] not in HostnameListtmp:
                HostnameListtmp.append(task[0])
            if len(task[1]) > 0:
                SubHostNameList = task[1]
        HostnameList = ",".join(HostnameListtmp)
        if len(SubHostNameList) > 0:
            HostnameList = HostnameList + ","+SubHostNameList

        return render_template('Review.html', HostnameList=HostnameList, Req_id=Req_id, firstname=firstname)
    
    else:
        is_valid = "Yes"
        return render_template('login.html',is_valid=is_valid)

@app.route('/ConfigurationStatus', methods=['GET', 'POST'])
def CreateConfig():
    if request.method == 'POST':
        if session.get('emailid') is not None and session.get('firstname') is not None and session.get('userid') is not None:
            EmailId = session.get('emailid')
            firstname = session.get('firstname')
            userid = session.get('userid')
        Req_id = request.form.get('Req_id')
        isSecureConfig = request.form.get('isSecureConfig')
        product = request.form.get('product')
        contractid=request.form.get('txtContractid')
        groupid=request.form.get('txtgroupid')
        accountid=request.form.get('txtacntid')
        originhostname=request.form.get('txtorigin')
        Edgehostname=request.form.get('txtEHN')

        db = pymysql.connect("localhost", "root", "password", "FIVR")
        cursor = db.cursor()
        sql = "SELECT HostName, SubHostName, URL FROM FIVR.Analysis WHERE RequestId = '%s'" % (Req_id)
        cursor.execute(sql)
        sql_results = cursor.fetchall()
        db.close()
        HostnameList = []
        url = []
        SubHostName = ""
        SubHostNamelist = []
        for a in sql_results:
            if a[0] not in HostnameList:
                HostnameList.append(a[0])
            url.append(a[2])
            SubHostName = a[1]
        if len(SubHostName) > 0:
            SubHostNamelist = SubHostName.split(", ")

            for a in SubHostNamelist:
                if a not in HostnameList:
                    HostnameList.append(a)

        ConfigName = str(HostnameList[0])+'-'+product

        isSuccess = "Yes"

        db = pymysql.connect("localhost", "root", "password", "FIVR")
        cursor = db.cursor()
        sql = "INSERT INTO FIVR.Configuration (RequestId, UserId, PropertyName, EdgeHostNames, SecureConfig, Product) VALUES ('%s','%s','%s','%s','%s','%s')" % (Req_id, userid, ConfigName, Edgehostname, isSecureConfig, product)
        try:
			cursor.execute(sql)
			db.commit()
        except:
			db.rollback()
        db.close()

        if(isSuccess == "Yes"):
			# Clone Config

			CloneConfigStatusTemp = CloneConfig(ConfigName, product, isSecureConfig,contractid, groupid, accountid)
			CloneConfigStatus = []
			CloneConfigStatus = CloneConfigStatusTemp.clone_config()
			if int(CloneConfigStatus[0]) == 201:
				NewCPCodeString = CloneConfigStatus[1]
				start = "/papi/v0/properties/"
				end = "?"
				NewProprtyId = NewCPCodeString[NewCPCodeString.find(start)+len(start):NewCPCodeString.rfind(end)]
				print "Config Created"
			else:
				print "Config Already exists"
				print CloneConfigStatus
				isSuccess = "No"

        if(isSuccess == "Yes"):
			#Add EHN to Config
			AddEHNToConfigStatusTemp = AddEhnToConfig(NewProprtyId, product, HostnameList, Edgehostname, isSecureConfig, contractid, groupid, accountid)
			AddEHNToConfigStatus = AddEHNToConfigStatusTemp.addEHN_config()
			if int(AddEHNToConfigStatus) == 200:
				print "EHN Updated"
			else:
				isSuccess = "No"
				print "EHN not Updated"

        if(isSuccess == "Yes"):
			#Create CP Code
            CpcodeName = str(HostnameList[0])
            CreateCPCodeTemp = CreateCPCode(CpcodeName, product, contractid, groupid, accountid)
            CreateCPCodeStatus = CreateCPCodeTemp.Create_CPCode()
            if int(CreateCPCodeStatus[0]) == 201:
                print "CPCode Created"
                NewCPCodeString = CreateCPCodeStatus[1]
                start = "/papi/v0/cpcodes/cpc_"
                end = "?"
                NewCPCodeID = NewCPCodeString[NewCPCodeString.find(start)+len(start):NewCPCodeString.rfind(end)]
                

            else:
				isSuccess = "No"
				print "CPCode Creation Failed"

        if(isSuccess == "Yes"):
			#Update Config
			UpdateConfigStatusTemp = UpdateConfig(NewProprtyId, product, HostnameList, originhostname, NewCPCodeID, isSecureConfig, Req_id, contractid, groupid, accountid)
			UpdateConfigStatus = UpdateConfigStatusTemp.update_config()
			if int(UpdateConfigStatus) == 200:
				print "Config Updated"
			else:
				isSuccess = "No"
				print "Config Not Updated"
        
        

        if(isSuccess == "Yes"):
			ActivateConfigStatusTemp = ActivateConfig(NewProprtyId, 'bchinmay')
			ActivateConfigStatus = ActivateConfigStatusTemp.activate_config()
			if int(ActivateConfigStatus) == 201:
				print "Config Activated in Staging"

			else:
				isSuccess = "NoActivate"
				print "Config could not be activated in staging"
        
        if(isSuccess == "Yes"):
            db = pymysql.connect("localhost", "root", "password", "FIVR")
            cursor = db.cursor()
            sql = "Update FIVR.Configuration SET PropertyId = '%s', StagingStatus = 'Pending Activation', ProductionStatus = 'Pending Activation', Timestamp = UTC_TIMESTAMP() WHERE RequestId = '%s'" % (NewProprtyId,Req_id)
            try:
                cursor.execute(sql)
                db.commit()
            except:
                db.rollback()

            sql = "UPDATE FIVR.Requests SET Status = 'Activation Pending' WHERE RequestId = '%s'" % (Req_id)
            try:
                cursor.execute(sql)
                db.commit()
            except:
                db.rollback()
            db.close()

        return render_template('ConfigurationStatus.html',isSuccess=isSuccess,Req_id=Req_id,configname=ConfigName,firstname=firstname)
    else:
        is_valid = "Yes"
        return render_template('login.html',is_valid=is_valid)

if __name__ == "__main__":
    app.run(threaded=True)
