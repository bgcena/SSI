import json
from urlparse import urljoin
from akamai.edgegrid import EdgeGridAuth
import requests

class CreateCPCode():
    def __init__(self,CPCodeName,product, contractid, groupid, accountid):
        self.CPCodeName = CPCodeName
        self.product = product
        self.contractid = contractid
        self.groupid = groupid
        self.accountid = accountid
    
    def Create_CPCode(self):
        baseurl = 'https://akab-lisr7zghtr7gns32-n6n5udzpnsapkylo.luna.akamaiapis.net'
        s = requests.Session()
        s.auth = EdgeGridAuth(
        client_secret = 'BLFXKTyLp4Qj0AmV6Dmimif1b3cGN56nvnPkw9bmvHs=',
        access_token = 'akab-gzlgszkohztaxi3x-wcryzueehzdppzzs',
        client_token = 'akab-mn7r6jnqgfvbd45j-kki7iblhmqmfulfy',
        )


        if self.product == "ION":
            productId = "prd_Fresca"
        else:
            productId = "prd_Site_Accel"

        pinfo_path = '/papi/v1/cpcodes?contractId='+self.contractid+'&groupId='+self.groupid+'&accountSwitchKey='+self.accountid
        pinfo_headers = {'PAPI-Use-Prefixes': 'true','Content-Type': 'application/json'}
        pinfo_data = json.dumps(
            {
            "productId": productId,
            "cpcodeName": self.CPCodeName,
            }
        )

        pinfo_res = s.post(urljoin(baseurl,pinfo_path),headers=pinfo_headers,data=pinfo_data)
        print pinfo_res.text
        return pinfo_res.status_code,pinfo_res.text
