import json
from urlparse import urljoin
from akamai.edgegrid import EdgeGridAuth
from GetCertDetails import GetCertDetails
import requests
import pymysql

class UpdateConfigComment():
    def __init__(self,configpropertyid):
        self.configpropertyid = configpropertyid

    def update_config_comment(self):
        baseurl = 'https://akab-556acphexmckxdwf-mv55g3nihy2y3wf5.luna.akamaiapis.net'
        s = requests.Session()
        s.auth = EdgeGridAuth(
            client_secret='aGx4XJ3DRJIxscyGfB2RaLe2JqKX7M2Iv9xW3nA7Ajw=',
            access_token='akab-zddyiew5gspaq4db-xvquxuk3mzmcxrlz',
            client_token='akab-tbvnwv2y7fj5c5l5-ic3fw7zwd7ce7w4l',
        )

        prule_path = "/papi/v1/properties/"+self.configpropertyid+"/versions/1/rules?contractId=ctr_C-20G24V&groupId=grp_28580"

        prule_res = s.get(urljoin(baseurl, prule_path))

        prule = json.loads(prule_res.text)

        prule['rules']['comments'] = "Initial Version Pushed from Self Service CAR"

        pupdate_header = {
            'Content-Type': 'application/json',
            'PAPI-Use-Prefixes': 'false'
        }
        pupdate_res = s.put(urljoin(baseurl, prule_path), 
                                headers=pupdate_header, data=json.dumps(prule))
        print "Comments Updated"
        
        return (pupdate_res.status_code)