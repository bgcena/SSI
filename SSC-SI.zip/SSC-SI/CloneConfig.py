import json
from urlparse import urljoin
from akamai.edgegrid import EdgeGridAuth
import requests

class CloneConfig():
    def __init__(self,configname,product,isSecureConfig, contractid, groupid, accountid):
        self.configname = configname
        self.product = product
        self.isSecureConfig = isSecureConfig
        self.contractid = contractid
        self.groupid = groupid
        self.accountid = accountid
    
    def clone_config(self):
        baseurl = 'https://akab-lisr7zghtr7gns32-n6n5udzpnsapkylo.luna.akamaiapis.net'
        s = requests.Session()
        s.auth = EdgeGridAuth(
        client_secret = 'BLFXKTyLp4Qj0AmV6Dmimif1b3cGN56nvnPkw9bmvHs=',
        access_token = 'akab-gzlgszkohztaxi3x-wcryzueehzdppzzs',
        client_token = 'akab-mn7r6jnqgfvbd45j-kki7iblhmqmfulfy',
        )


        if self.product == "ION" and self.isSecureConfig == "No":
            productId = "prd_Fresca"
        elif self.product == "DSA" and self.isSecureConfig == "No":
            productId = "prd_Site_Accel"
        elif self.product == "DSA" and self.isSecureConfig == "Yes":
            productId = "prd_Site_Accel"
        else:
            productId = "prd_Fresca"

        pinfo_path = '/papi/v1/properties?contractId='+self.contractid+'&groupId='+self.groupid+'&accountSwitchKey='+self.accountid
        pinfo_headers = {'PAPI-Use-Prefixes': 'true','Content-Type': 'application/json'}
        pinfo_data = json.dumps(
            {
            "productId": productId,
            "propertyName": self.configname,
            }
        )

        pinfo_res = s.post(urljoin(baseurl,pinfo_path),headers=pinfo_headers,data=pinfo_data)
        return pinfo_res.status_code,pinfo_res.text
