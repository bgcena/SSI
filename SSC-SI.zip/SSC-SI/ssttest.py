from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from browsermobproxy import Server
from urlparse import urlparse
import json
import random
import codecs
import socket

class getHar():
	global browser
	global chrome_options
	global proxy
	global server
	
	
	def __init__(self,url,is_mobile,test_id):
		self.url = url
		self.is_mobile = is_mobile
		self.test_id = test_id
		
	def getHarFile(self):

		server=Server('c:/browsermob-proxy-2.1.4/bin/browsermob-proxy')
		server.start()
		proxy=server.create_proxy()
		
		if self.is_mobile == "Yes":
			chrome_options = Options()
			mobile_emulation = {"deviceMetrics": { "width": 412, "height": 732},"userAgent": "Mozilla/5.0 (Linux; U; Android 7.1.1; en-us; MI 6 Build/NMF26X) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/53.0.2785.146 Mobile Safari/537.36 XiaoMi/MiuiBrowser/8.8.7" }
			chrome_options.add_experimental_option("mobileEmulation", mobile_emulation)
		else:
			chrome_options = Options()
		
		chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
		chrome_options.add_argument("--enable-http2")
		chrome_options.add_argument("--aggressive-cache-discard")
		proxy.new_har("test", options={'captureHeaders': True})
		browser = webdriver.Chrome(executable_path="c:/chromedriver",chrome_options = chrome_options)
		success=''
		browser.set_page_load_timeout(60)
		try:
			browser.get(self.url)
			har=proxy.har
			parsed = urlparse(self.url)
			inputHostname = parsed.netloc
			harpath = 'c:/SSC-SI/Harfiles/'+str(inputHostname)+str(self.test_id)+'.har'
			with codecs.open(harpath, 'w+',encoding='utf8') as outfile:
				json.dump(har, outfile, ensure_ascii=False)
			browser.close()
			browser.quit()
			success='yes'
		except:
			harpath = 'c:/SSC-SI/Harfiles/'+str(self.test_id)+'.har'
			success='no'
			browser.close()
			browser.quit()
		return harpath,success